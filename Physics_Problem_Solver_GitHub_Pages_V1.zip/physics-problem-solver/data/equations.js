export const V={v:["final velocity","m/s"],v0:["initial velocity","m/s"],a:["acceleration","m/s²"],t:["time","s"],dx:["displacement","m"],m:["mass","kg"],F:["net force","N"],KE:["kinetic energy","J"],h:["height","m"],p:["momentum","kg·m/s"],f:["frequency","Hz"],lambda:["wavelength","m"],V:["voltage","V"],I:["current","A"],R:["resistance","Ω"]};
export const C={g:9.81};
export const E=[
{id:"vat",name:"Velocity kinematics",formula:"v = v₀ + at",vars:["v","v0","a","t"],principle:"Kinematics",condition:"Constant acceleration"},
{id:"xat",name:"Displacement kinematics",formula:"Δx = v₀t + ½at²",vars:["dx","v0","a","t"],principle:"Kinematics",condition:"Constant acceleration"},
{id:"nos",name:"No-time kinematics",formula:"v² = v₀² + 2aΔx",vars:["v","v0","a","dx"],principle:"Kinematics",condition:"Constant acceleration"},
{id:"newton",name:"Newton's Second Law",formula:"ΣF = ma",vars:["F","m","a"],principle:"Forces",condition:"Net force"},
{id:"ke",name:"Kinetic Energy",formula:"KE = ½mv²",vars:["KE","m","v"],principle:"Energy",condition:"Classical mechanics"},
{id:"pe",name:"Gravitational Potential Energy",formula:"PE = mgh",vars:["KE","m","h"],principle:"Energy",condition:"Near Earth"},
{id:"mom",name:"Momentum",formula:"p = mv",vars:["p","m","v"],principle:"Momentum",condition:"Classical mechanics"},
{id:"wave",name:"Wave equation",formula:"v = fλ",vars:["v","f","lambda"],principle:"Waves",condition:"Wave relationship"},
{id:"ohm",name:"Ohm's Law",formula:"V = IR",vars:["V","I","R"],principle:"Electricity",condition:"Ohmic component"}
];