# Physics Problem Solver V1
Upload this folder to a GitHub repository and enable GitHub Pages.

## Current features
- Equation database
- Known/target input
- Unknown counter
- Equation ranking
- Recursive dependency search
- Shortest path ordering
- Alternative paths
- Repeated transformation protection

## Important note
One equation in the starter data (`PE = mgh`) is intentionally only a structural placeholder for the next expansion; Version 2 should add a dedicated PE variable and much larger equation coverage.

## GitHub Pages
Repository Settings → Pages → Deploy from branch → main → /(root).
